#!/usr/bin/env bash

source data/common.sh

Test	ArrayList	TestList	list
Test	CursorList	TestList	list
