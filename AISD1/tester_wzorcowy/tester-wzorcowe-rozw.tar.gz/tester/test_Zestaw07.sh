#!/usr/bin/env bash

source data/common.sh

Test	Dict		TestDict	dict	data/dict/pairs.txt
