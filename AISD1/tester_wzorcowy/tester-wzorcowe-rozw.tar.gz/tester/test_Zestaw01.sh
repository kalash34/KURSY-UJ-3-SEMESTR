#!/usr/bin/env bash

source data/common.sh

Test	Stack	TestStack	stackqueue
Test	ONP		TestRPN		onp
