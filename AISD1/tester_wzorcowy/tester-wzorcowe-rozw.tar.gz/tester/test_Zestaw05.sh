#!/usr/bin/env bash

source data/common.sh

Test	BubbleSort		TestSort	sort
Test	SelectionSort	TestSort	sort
Test	InsertionSort	TestSort	sort

