#!/usr/bin/env bash

source data/common.sh

Test	Queue	TestQueue	stackqueue
Test	Radix	TestSort	sort
