#!/usr/bin/env bash

source data/common.sh

Test	LinkedList	TestList	list
