#!/usr/bin/env bash

source data/common.sh

Test	BinaryTree		TestTree	tree
